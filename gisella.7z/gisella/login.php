<?php

// Conexión a la base de datos
$host = "localhost";
$user = "root";
$pass = "";
$db = "exploraquibdo";
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

session_start();
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = $conn->real_escape_string($_POST['correo']);
    $contraseña = $_POST['contraseña'];

    $sql = "SELECT id, nombre_completo, contraseña, estado FROM usuarios WHERE correo='$correo' LIMIT 1";
    $res = $conn->query($sql);

    if ($res && $res->num_rows == 1) {
        $row = $res->fetch_assoc();
        if (password_verify($contraseña, $row['contraseña'])) {
            if ($row['estado'] == 'activo') {
                $_SESSION['usuario_id'] = $row['id'];
                $_SESSION['nombre'] = $row['nombre_completo'];
                header("Location: index.html");
                exit();
            } else {
                $mensaje = "Tu cuenta no está activa. Revisa tu correo o contacta soporte.";
            }
        } else {
            $mensaje = "Contraseña incorrecta.";
        }
    } else {
        $mensaje = "Correo no registrado.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión - ExploraQuibdó</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;600&family=Open+Sans:wght@300;400&display=swap" rel="stylesheet">
    <style>
        <?php include 'estilos.css'; ?>
    </style>
</head>
<body style="background-color: #F5F5F5;">
    <div class="container d-flex align-items-center justify-content-center" style="min-height: 100vh;">
        <div class="login-form w-100" style="max-width:400px;">
            <h2 class="mb-4 text-center">Iniciar Sesión</h2>
            <?php if ($mensaje): ?>
                <div class="alert alert-danger"><?php echo $mensaje; ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label for="correo" class="form-label">Correo electrónico</label>
                    <input type="email" class="form-control" id="correo" name="correo" required>
                </div>
                <div class="mb-3">
                    <label for="contraseña" class="form-label">Contraseña</label>
                    <input type="password" class="form-control" id="contraseña" name="contraseña" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Iniciar Sesión</button>
            </form>
            <div class="text-center mt-3">
                <a href="registro.php" class="text-primary">¿No tienes cuenta? Regístrate aquí</a>
            </div>
        </div>
    </div>
</body>
</html>